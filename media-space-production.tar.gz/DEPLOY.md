# Медіа Простір / Media Space - Deployment Guide

## 📁 Файловая структура для загрузки

```
dist/
├── index.html          # Главная точка входа
├── assets/             # JS, CSS, шрифты (автоматически сгенерированы)
│   ├── index-xxx.js
│   └── index-xxx.css
├── _redirects          # Для Netlify
├── .htaccess           # Для Apache серверов
├── vercel.json         # Для Vercel
└── netlify.toml        # Для Netlify (альтернатива _redirects)
```

**Загружать на сервер нужно ТОЛЬКО содержимое папки `dist/`**

---

## 🚀 Варианты развертывания

### 1. Vercel (Рекомендуется)

```bash
# Установите Vercel CLI
npm i -g vercel

# В папке dist/
cd dist
vercel --prod
```

Или просто перетащите папку `dist/` на [vercel.com](https://vercel.com)

---

### 2. Netlify

```bash
# Установите Netlify CLI
npm i -g netlify-cli

# В папке dist/
cd dist
netlify deploy --prod
```

Или перетащите папку `dist/` на [netlify.com](https://netlify.com)

---

### 3. Apache/Nginx (Shared Hosting)

1. Загрузите содержимое `dist/` в корневую папку сайта (обычно `public_html/`)
2. Файл `.htaccess` уже настроен для правильной работы SPA

---

### 4. Поддомен (subdomain.example.com)

1. Создайте поддомен в панели управления хостингом
2. Укажите корневую папку поддомена
3. Загрузите содержимое `dist/` в эту папку

---

## ⚙️ Конфигурационные файлы

### Для Apache (.htaccess)
- Перенаправление всех запросов на index.html (SPA routing)
- Gzip сжатие
- Кэширование статических файлов
- Security headers

### Для Vercel (vercel.json)
- Rewrites для SPA
- Кэширование assets
- Security headers

### Для Netlify (_redirects / netlify.toml)
- Перенаправление всех путей на index.html
- Кэширование

---

## 🔐 Кодовые слова для регистрации

**User (обычный доступ):**
```
TELEGRAM_INTELLIGENCE_2024_SECURE_ACCESS
```

**Admin (полный доступ):**
```
TELEGRAM_INTELLIGENCE_2024_ADMIN_SUPER_ACCESS
```

---

## 📋 Проверка после развертывания

1. ✅ Главная страница загружается
2. ✅ Переключение UA/EN работает
3. ✅ Регистрация с кодовым словом работает
4. ✅ Логин работает
5. ✅ Фильтрация каналов по региону работает
6. ✅ Фильтрация по рейтинговым цветам работает
7. ✅ Admin Panel доступна для admin-аккаунтов
8. ✅ Создание/редактирование каналов работает
9. ✅ Загрузка изображений работает
10. ✅ Загрузка PDF работает

---

## 🛠️ Внесение изменений

Если нужно изменить сайт:

```bash
# 1. Установить зависимости
npm install

# 2. Внести изменения в src/

# 3. Пересобрать
npm run build

# 4. Заново загрузить dist/ на сервер
```

---

## ⚠️ Важно

- **localStorage** привязан к домену — данные не перенесутся автоматически
- При смене домена пользователи потеряют свои данные
- Для переноса данных используйте экспорт/импорт localStorage
